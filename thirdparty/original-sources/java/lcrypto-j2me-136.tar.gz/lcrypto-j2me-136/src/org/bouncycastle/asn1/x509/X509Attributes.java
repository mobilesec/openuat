package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.DERObjectIdentifier;

public class X509Attributes
{
    public static final DERObjectIdentifier RoleSyntax = new DERObjectIdentifier("2.5.4.72");
}
