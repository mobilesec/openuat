/* Copyright Tamás Vajk
 * Based on public domain example code by Nokia.
 * File created 2007-03
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef SOCKETSERVER_H_
#define SOCKETSERVER_H_

#include <e32base.h>

#include <es_sock.h>
#include <in_sock.h>

enum TState {EDisconnected=1, EAccepting, EReceiving};

class CAccelerometerHandler;

class CSocketServer : public CActive
{
public:
	static CSocketServer* NewL();
	static CSocketServer* NewLC();
	~CSocketServer();

	void StartServerL();
	
	void ReceiveCommand();
	void Stop();
protected:
	CSocketServer();
	void ConstructL();
	void DoCancel();
	void RunL();

	
private:	
	RConnection iConnection; 
	RSocketServ iSocketServer;

	RSocket iSocket;

	TBuf8<2> iBuffer;
	RSocket iAcceptedSocket;
    TSockXfrLength iLen;
	RSocket* iActiveSocket;
	TState iState;
	
	CAccelerometerHandler* iAccHandler;
}; 

#endif /*SOCKETSERVER_H_*/
