/* Copyright Tamás Vajk
 * Based on public domain example code by Nokia.
 * File created 2007-03
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#ifndef ACCELEROMETERHANDLER_H_
#define ACCELEROMETERHANDLER_H_

#include <rrsensorapi.h>
#include <in_sock.h>
#include <es_sock.h>
#include <e32base.h>
#include <e32std.h>

// Accelerometer implementation Id
// From rrsensorapi.h
const TInt Kacc = 0x10273024;

class CAccelerometerHandler : public MRRSensorDataListener
{
public:
		static CAccelerometerHandler* NewL(RSocketServ* rss);
        static CAccelerometerHandler* NewLC(RSocketServ* rss);
        virtual ~CAccelerometerHandler();
        
        void HandleDataEventL( TRRSensorInfo aSensor, TRRSensorEvent aEvent );
        
private:
	CAccelerometerHandler();
	void ConstructL(RSocketServ* rss);
	void SendMessageL( const TDesC8& aText );
	
	CRRSensorApi* iAccSensor;

	RSocketServ* iSocketServ;
	RSocket iSenderSocket;
	
		TInt iMovingAVGActualDataNumberX;
		TInt iMovingSUMX;
		
		TInt iMovingSUMXValues[3];
		
		TInt iMovingAVGActualDataNumberY;
		TInt iMovingSUMY;
		
		TInt iMovingSUMYValues[3];
		
		TInt iMovingAVGActualDataNumberZ;
		TInt iMovingSUMZ;
		
		TInt iMovingSUMZValues[3];
};

#endif /*ACCELEROMETERHANDLER_H_*/
