/*
============================================================================
 Name        : SensorDaemon.h
 Author      : Tamas Vajk
 Copyright   : Tamas Vajk, based on public domain example code by Nokia.
 Description : Exe header file

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
============================================================================
*/

#ifndef __SENSORDAEMON_H__
#define __SENSORDAEMON_H__


//  Include Files

#include <e32base.h>


//  Function Prototypes

GLDEF_C TInt E32Main();


#endif  // __SENSORDAEMON_H__


