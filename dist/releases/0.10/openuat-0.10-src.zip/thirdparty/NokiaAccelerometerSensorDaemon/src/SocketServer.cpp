/* Copyright Tamás Vajk
 * Based on public domain example code by Nokia.
 * File created 2007-03
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "SocketServer.h"
#include "AccelerometerHandler.h"


CSocketServer* CSocketServer::NewL()
{
    CSocketServer* self = NewLC();
    CleanupStack::Pop( self );
    return self;
}

CSocketServer* CSocketServer::NewLC()
{
    CSocketServer* self = new ( ELeave ) CSocketServer(  );
    CleanupStack::PushL( self );
    self->ConstructL();
    return self;
}

CSocketServer::CSocketServer():CActive(EPriorityStandard)
{
	CActiveScheduler::Add(this);
	iState=EDisconnected;
}

void CSocketServer::ConstructL()
{
	User::LeaveIfError( iSocketServer.Connect() );
} 

CSocketServer::~CSocketServer()
{
	    if ( iState == EReceiving )
        {
        if ( iActiveSocket )
            {
            iActiveSocket->CancelRead();
            }
        }
    Cancel();
    iAcceptedSocket.Close();
    iSocket.Close();
    iSocketServer.Close();
}

void CSocketServer::StartServerL()
{
	if ( iState != EDisconnected )
        {
        User::Leave( KErrInUse );
        }
        
    TInt result( 0 );
    
    result = iSocket.Open( iSocketServer, 
        KAfInet, 
        KSockStream, 
        KProtocolInetTcp );
      
      
    if ( result != KErrNone )
        {
        iSocketServer.Close();
        User::Leave( result ); 
        }

	iSocket.SetLocalPort(8100);

    // listen
    User::LeaveIfError( iSocket.Listen( 1 ) );
    // close old connection - if any
    iAcceptedSocket.Close();

    // Open abstract socket
    User::LeaveIfError( iAcceptedSocket.Open( iSocketServer ) );
    iActiveSocket = &iAcceptedSocket;
      
    iSocket.Accept( iAcceptedSocket, iStatus );
    iState = EAccepting;
    SetActive();	
}

void CSocketServer::ReceiveCommand()
{
	iActiveSocket->RecvOneOrMore(iBuffer,0,iStatus,iLen);
	iState=EReceiving;
	SetActive();
}

void CSocketServer::DoCancel()
{	
    if ( iState == EReceiving )
        {
        if ( iActiveSocket )
            {
            iActiveSocket->CancelRead();
            }
        }
	iState=EDisconnected;
}

void CSocketServer::Stop()
    {
    if ( iState != EDisconnected )
        {
        if ( iState == EReceiving )
            {
            if ( iActiveSocket )
                {
                iActiveSocket->CancelRead();
                }
            }
        iAcceptedSocket.Close();
        iSocket.Close();
        }
        iState = EDisconnected;
    }

void CSocketServer::RunL()
{		
	if(( iStatus == KErrDisconnected ) || ( iStatus == KErrEof ) || ( iStatus == KErrAbort ))
	{
					if (iAccHandler)
					{
						delete iAccHandler;
						iAccHandler = NULL;
					}
		Stop();
		StartServerL();
	}
	else if (iStatus != KErrNone)
	{
					if (iAccHandler)
					{
						delete iAccHandler;
						iAccHandler = NULL;
					}
		Stop();
		StartServerL();
	}
	else
	{		
		switch(iState)
		{
			case EAccepting:
			{			
				ReceiveCommand();			
				break;
			}
			case EReceiving:
			{
				TInt buf = (TInt)(iBuffer[0]); 
				
				if (buf == 115)//"s"
				{					
					//create Sensor data sender
					if (iAccHandler)
					{
						delete iAccHandler;
						iAccHandler = NULL;
					}
					iAccHandler = CAccelerometerHandler::NewL(&iSocketServer);
					
				}
				else if (buf == 101)//"e", actually it is not necessary, because if the connection is lost, the same happens
				{
					
					//delete Sensor data sender
					if (iAccHandler)
					{
						delete iAccHandler;
						iAccHandler = NULL;
					}
					
				}
				else
				{
					//err: no other command is defined now
				}
												
				iBuffer.Zero();
				ReceiveCommand();
				break;
			}
			case EDisconnected:
                break;
		}
	}
}


