/* Copyright Tamás Vajk
 * Based on public domain example code by Nokia.
 * File created 2007-03
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "AccelerometerHandler.h"

CAccelerometerHandler* CAccelerometerHandler::NewL(RSocketServ* rss)
{
    CAccelerometerHandler* self = NewLC(rss);
    CleanupStack::Pop( self );
    return self;
}

CAccelerometerHandler* CAccelerometerHandler::NewLC(RSocketServ* rss)
{
    CAccelerometerHandler* self = new ( ELeave ) CAccelerometerHandler(  );
    CleanupStack::PushL( self );
    self->ConstructL (rss);
    return self;
}

void CAccelerometerHandler::ConstructL(RSocketServ* rss)
{
	iSocketServ = rss;	
	
	TUint KTestPort=8101;
	TInetAddr addr(KInetAddrLoop, KTestPort);
	
	// Open a TCP socket
    User::LeaveIfError( iSenderSocket.Open( 	*iSocketServ,
								        		KAfInet,
								        		KSockStream,
								        		KProtocolInetTcp ) );

	TRequestStatus status;
    // Initiate socket connection
    iSenderSocket.Connect( addr, status );
    User::WaitForRequest(status);
	if(status != KErrNone) User::Leave(KErrCouldNotConnect);

	RArray <TRRSensorInfo> sensorList;
	CRRSensorApi::FindSensorsL( sensorList );
	        
	//Number of sensors available
	TInt sensorCount = sensorList.Count();

	for( TInt i = 0 ; i != sensorCount ; i++ )
	{
		if( sensorList[i].iSensorId == Kacc )
		{
			iAccSensor = CRRSensorApi::NewL( sensorList[i] );
			iAccSensor->AddDataListener( this );
		}
	}
}

CAccelerometerHandler::CAccelerometerHandler()
{	
}

CAccelerometerHandler::~CAccelerometerHandler()
{
	iSenderSocket.Close();
	
	if (iAccSensor)
	{
		iAccSensor->RemoveDataListener();
		delete iAccSensor;
		iAccSensor = NULL;
	}
}
void CAccelerometerHandler::SendMessageL( const TDesC8& aText )
{
	TRequestStatus status;
			    
	iSenderSocket.Write(aText, status);
	User::WaitForRequest(status); 
	if(status != KErrNone) User::Leave(KErrGeneral);
}
void CAccelerometerHandler::HandleDataEventL( TRRSensorInfo aSensor, TRRSensorEvent aEvent )
{
        switch ( aSensor.iSensorId )
		{
            case Kacc:
				{
					TBuf8<5> dataToSend;
					
					TInt8 x((aEvent.iSensorData1>>5) + 100);
	          		dataToSend.Append(x);
	          		TInt8 y((aEvent.iSensorData2>>5) + 100);
	          		dataToSend.Append(y);
	          		TInt8 z((aEvent.iSensorData3>>5) + 100);
	          		dataToSend.Append(z);
	          		
	          		TInt8 stopSign(1);
          			dataToSend.Append(stopSign);
          		
          			SendMessageL(dataToSend);
				}
				break;
			
            default:
              	break;
		}  
}

