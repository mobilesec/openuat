/*
============================================================================
 Name        : SensorDaemon.cpp
 Author      : Tamas Vajk
 Copyright   : Tamas Vajk, based on public domain example code by Nokia.
 Description : Exe source file

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU Lesser General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.
============================================================================
*/

#include "SensorDaemon.h"
#include <e32base.h>
#include <e32std.h>
#include <e32cons.h>            // Console

#include "SocketServer.h"

//  Constants

_LIT(KTextConsoleTitle, "SensorDaemon");
_LIT(KTextFailed, " failed, leave code = %d");
_LIT(KTextPressAnyKey, " [press any key]\n");


//  Global Variables



LOCAL_C void DoStartL()
    {
    // Create active scheduler (to run active objects)
    CActiveScheduler* scheduler = new (ELeave) CActiveScheduler();
    CleanupStack::PushL(scheduler);
    CActiveScheduler::Install(scheduler);

    //MainL();
    
    CSocketServer* socketServer = CSocketServer::NewL();
	socketServer->StartServerL();
	
	CActiveScheduler::Start();


	delete socketServer;
    // Delete active scheduler
    CleanupStack::PopAndDestroy(scheduler);
    
    }


//  Global Functions

GLDEF_C TInt E32Main()
    {
    // Create cleanup stack
    __UHEAP_MARK;
    CTrapCleanup* cleanup = CTrapCleanup::New();
    
    RTimer timer;                // The asynchronous timer and ...
    TRequestStatus timerStatus; // ... its associated request status
    timer.CreateLocal();
    timer.After(timerStatus,10000000); // wait 10 second
    User::WaitForRequest(timerStatus);
    timer.Close();
    
	
    // Run application code inside TRAP harness, wait keypress when terminated
    TRAPD(mainError, DoStartL());

    delete cleanup;
    __UHEAP_MARKEND;
    return KErrNone;
    }



