package org.openuat.roles;

public class Duckling {

}
