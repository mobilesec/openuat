package org.openuat.roles;

public class MotherDuck {

}
